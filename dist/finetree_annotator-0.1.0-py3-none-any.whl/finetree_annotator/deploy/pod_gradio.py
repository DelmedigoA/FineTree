from __future__ import annotations

import argparse
import base64
import html
import inspect
import json
import mimetypes
import os
import re
import secrets
import tempfile
from pathlib import Path
from typing import Any, Iterator, Optional
from urllib import error as urllib_error
from urllib import parse as urllib_parse
from urllib import request as urllib_request

from pydantic import BaseModel, Field

_DEFAULT_TINY_IMAGE_DATA_URL = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO6p6nQAAAAASUVORK5CYII="
)


class PlaygroundChatRequest(BaseModel):
    system_prompt: str = ""
    user_prompt: str = ""
    model: str = "qwen-gt"
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    top_p: float = Field(default=0.8, gt=0.0, le=1.0)
    max_tokens: int = Field(default=120, ge=1, le=4096)
    image_data_url: Optional[str] = None
    history: list[dict[str, str]] = Field(default_factory=list)


def _project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _default_example_image_path() -> Optional[Path]:
    explicit = str(os.getenv("FINETREE_GRADIO_EXAMPLE_IMAGE") or "").strip()
    if explicit:
        explicit_path = Path(explicit).expanduser()
        if explicit_path.is_file():
            return explicit_path.resolve()

    root = _project_root()
    preferred = root / "data" / "pdf_images" / "test" / "page_0001.png"
    if preferred.is_file():
        return preferred.resolve()

    for pattern in ("*.png", "*.jpg", "*.jpeg", "*.webp"):
        matches = sorted((root / "data" / "pdf_images").rglob(pattern))
        for match in matches:
            if match.is_file():
                return match.resolve()
    return None


def _image_file_to_data_url(image_path: Path) -> str:
    import base64
    import mimetypes

    mime = mimetypes.guess_type(str(image_path))[0] or "image/png"
    payload = base64.b64encode(image_path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{payload}"


def _resolve_basic_auth_credentials() -> tuple[str, str]:
    username = str(os.getenv("FINETREE_PLAYGROUND_USER") or os.getenv("FINETREE_GRADIO_USER") or "").strip()
    password = str(os.getenv("FINETREE_PLAYGROUND_PASS") or os.getenv("FINETREE_GRADIO_PASS") or "").strip()
    if not username or not password:
        raise RuntimeError(
            "Playground auth is required. "
            "Set FINETREE_PLAYGROUND_USER/FINETREE_PLAYGROUND_PASS "
            "or FINETREE_GRADIO_USER/FINETREE_GRADIO_PASS."
        )
    return username, password


def _resolve_pod_api_key() -> str:
    api_key = str(os.getenv("FINETREE_POD_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("FINETREE_POD_API_KEY is required for playground-to-API calls.")
    return api_key


def _resolve_api_base_url(explicit_api_base_url: Optional[str]) -> str:
    candidate = str(explicit_api_base_url or os.getenv("FINETREE_PLAYGROUND_API_BASE_URL") or "http://127.0.0.1:6666")
    return candidate.rstrip("/")


def _normalize_model_selector(model_name: str) -> str:
    raw = str(model_name or "").strip().lower()
    if not raw:
        return ""
    return re.sub(r"-+", "-", re.sub(r"[\s_]+", "-", raw))


def _is_gemini_model_requested(model_name: str) -> bool:
    normalized = _normalize_model_selector(model_name)
    if not normalized:
        return False
    if normalized in {"gemini", "gemini-gt"}:
        return True
    if normalized.startswith("gemini-"):
        return True
    if normalized.startswith("google/gemini") or normalized.startswith("models/gemini"):
        return True
    return False


def _resolve_gemini_model_name(model_name: str) -> str:
    normalized = _normalize_model_selector(model_name)
    try:
        from ..gemini_vlm import DEFAULT_GEMINI_MODEL
    except Exception:
        DEFAULT_GEMINI_MODEL = "gemini-3-flash-preview"

    alias_default = str(os.getenv("FINETREE_GEMINI_MODEL") or DEFAULT_GEMINI_MODEL).strip() or DEFAULT_GEMINI_MODEL
    if normalized in {"", "gemini", "gemini-gt"}:
        return alias_default

    resolved = str(model_name or "").strip() or alias_default
    lowered = resolved.lower()
    if lowered.startswith("google/"):
        resolved = resolved.split("/", 1)[1].strip() or alias_default
    elif lowered.startswith("models/"):
        resolved = resolved.split("/", 1)[1].strip() or alias_default
    return resolved


def _build_gemini_prompt(*, system_prompt: str, user_prompt: str, history: list[dict[str, str]]) -> str:
    contextual_prompt = _build_contextual_user_prompt(user_prompt=user_prompt, history=history)
    system_text = str(system_prompt or "").strip()
    if not system_text:
        return contextual_prompt
    return f"System instruction:\n{system_text}\n\n{contextual_prompt}"


def _data_url_to_temp_image_path(data_url: str) -> Path:
    raw_data_url = str(data_url or "").strip()
    if not raw_data_url.startswith("data:") or "," not in raw_data_url:
        raise ValueError("Invalid image data URL.")

    header, payload = raw_data_url.split(",", 1)
    mime_part = header[5:].split(";", 1)[0].strip().lower() or "image/png"
    is_base64 = ";base64" in header.lower()
    if is_base64:
        image_bytes = base64.b64decode(payload)
    else:
        image_bytes = urllib_parse.unquote_to_bytes(payload)

    suffix = mimetypes.guess_extension(mime_part) or ".img"
    with tempfile.NamedTemporaryFile(prefix="finetree-gemini-", suffix=suffix, delete=False) as tmp:
        tmp.write(image_bytes)
        tmp.flush()
        return Path(tmp.name)


def _prepare_gemini_image_path(*, image_path: Optional[str], image_data_url: Optional[str]) -> tuple[Path, bool]:
    image_path_raw = str(image_path or "").strip()
    if image_path_raw:
        candidate = Path(image_path_raw).expanduser()
        if not candidate.is_file():
            raise FileNotFoundError(f"Image not found: {candidate}")
        return candidate.resolve(), False

    source_data_url = str(image_data_url or "").strip() or _DEFAULT_TINY_IMAGE_DATA_URL
    return _data_url_to_temp_image_path(source_data_url), True


def _generate_gemini_response(
    *,
    model_name: str,
    prompt: str,
    image_path: Optional[str],
    image_data_url: Optional[str],
) -> str:
    from ..gemini_vlm import generate_content_from_image

    resolved_model = _resolve_gemini_model_name(model_name)
    image_file, should_cleanup = _prepare_gemini_image_path(
        image_path=image_path,
        image_data_url=image_data_url,
    )
    try:
        return generate_content_from_image(
            image_path=image_file,
            prompt=prompt,
            model=resolved_model,
        )
    finally:
        if should_cleanup:
            image_file.unlink(missing_ok=True)


def _stream_gemini_response(
    *,
    model_name: str,
    prompt: str,
    image_path: Optional[str],
    image_data_url: Optional[str],
) -> Iterator[str]:
    from ..gemini_vlm import stream_content_from_image

    resolved_model = _resolve_gemini_model_name(model_name)
    image_file, should_cleanup = _prepare_gemini_image_path(
        image_path=image_path,
        image_data_url=image_data_url,
    )
    try:
        yield from stream_content_from_image(
            image_path=image_file,
            prompt=prompt,
            model=resolved_model,
        )
    finally:
        if should_cleanup:
            image_file.unlink(missing_ok=True)


def _extract_assistant_text(payload: dict[str, Any]) -> str:
    try:
        choice = payload["choices"][0]
    except Exception:
        return json.dumps(payload, ensure_ascii=False)

    message = choice.get("message")
    if isinstance(message, dict):
        content = message.get("content")
        if isinstance(content, str):
            return content

    delta = choice.get("delta")
    if isinstance(delta, dict):
        content = delta.get("content")
        if isinstance(content, str):
            return content

    return json.dumps(payload, ensure_ascii=False)


def _normalize_history(raw_history: Any) -> list[dict[str, str]]:
    if not isinstance(raw_history, list):
        return []
    normalized: list[dict[str, str]] = []
    for item in raw_history:
        if not isinstance(item, dict):
            continue
        user_text = str(item.get("user") or "").strip()
        assistant_text = str(item.get("assistant") or "").strip()
        if not user_text and not assistant_text:
            continue
        normalized.append({"user": user_text, "assistant": assistant_text})
    return normalized


def _build_contextual_user_prompt(user_prompt: str, history: list[dict[str, str]]) -> str:
    prompt = str(user_prompt or "").strip() or "Describe this image."
    if not history:
        return prompt

    # Keep recent turns only to avoid runaway prompt growth.
    recent = history[-12:]
    lines: list[str] = ["Conversation context:"]
    for turn in recent:
        turn_user = str(turn.get("user") or "").strip()
        turn_assistant = str(turn.get("assistant") or "").strip()
        if turn_user:
            lines.append(f"User: {turn_user}")
        if turn_assistant:
            lines.append(f"Assistant: {turn_assistant}")
    lines.append(f"User: {prompt}")
    lines.append("Assistant:")
    return "\n".join(lines)


def _build_openai_chat_payload(request_payload: dict[str, Any]) -> dict[str, Any]:
    system_prompt = str(request_payload.get("system_prompt") or "").strip()
    user_prompt = str(request_payload.get("user_prompt") or "").strip() or "Describe this image."
    model = str(request_payload.get("model") or "").strip() or "qwen-gt"
    image_data_url = str(request_payload.get("image_data_url") or "").strip() or _DEFAULT_TINY_IMAGE_DATA_URL
    history = _normalize_history(request_payload.get("history"))
    contextual_prompt = _build_contextual_user_prompt(user_prompt=user_prompt, history=history)

    messages: list[dict[str, Any]] = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})

    messages.append(
        {
                "role": "user",
                "content": [
                    {"type": "text", "text": contextual_prompt},
                    {"type": "image_url", "image_url": {"url": image_data_url}},
                ],
            }
        )

    payload: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": int(request_payload.get("max_tokens") or 120),
    }

    temperature = float(request_payload.get("temperature") or 0.7)
    top_p = float(request_payload.get("top_p") or 0.8)
    if temperature > 0.0:
        payload["temperature"] = temperature
        payload["top_p"] = top_p

    return payload


def _post_json(url: str, body: dict[str, Any], api_key: str, timeout_sec: float) -> dict[str, Any]:
    req = urllib_request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib_request.urlopen(req, timeout=timeout_sec) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw)
    except urllib_error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Upstream API error {exc.code}: {raw[:1000]}") from exc
    except urllib_error.URLError as exc:
        raise RuntimeError(f"Failed to reach upstream API: {exc}") from exc


def _iter_sse_data_events(url: str, body: dict[str, Any], api_key: str, timeout_sec: float) -> Iterator[str]:
    req = urllib_request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "Cache-Control": "no-cache",
        },
        method="POST",
    )
    try:
        with urllib_request.urlopen(req, timeout=timeout_sec) as response:
            data_lines: list[str] = []
            for raw_line in response:
                line = raw_line.decode("utf-8", errors="replace").rstrip("\r\n")
                if not line:
                    if data_lines:
                        yield "\n".join(data_lines)
                        data_lines = []
                    continue
                if line.startswith(":"):
                    continue
                field, sep, value = line.partition(":")
                if not sep or field != "data":
                    continue
                if value.startswith(" "):
                    value = value[1:]
                data_lines.append(value)
            if data_lines:
                yield "\n".join(data_lines)
    except urllib_error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Upstream API error {exc.code}: {raw[:1000]}") from exc
    except urllib_error.URLError as exc:
        raise RuntimeError(f"Failed to reach upstream API: {exc}") from exc


def _message_content_to_text(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, dict):
        text = content.get("text")
        if isinstance(text, str):
            return text.strip()
        path = content.get("path")
        if isinstance(path, str):
            return path.strip()
        return ""
    if isinstance(content, list):
        chunks: list[str] = []
        for item in content:
            text = _message_content_to_text(item)
            if text:
                chunks.append(text)
        return "\n".join(chunks).strip()
    return ""


def _history_messages_to_turns(history: Any) -> list[dict[str, str]]:
    if not isinstance(history, list):
        return []

    # Older Gradio ChatInterface provides history as list[(user, assistant)] tuples.
    if history and isinstance(history[0], (list, tuple)):
        tuple_turns: list[dict[str, str]] = []
        for item in history:
            if not isinstance(item, (list, tuple)) or len(item) != 2:
                continue
            user_text = _message_content_to_text(item[0])
            assistant_text = _message_content_to_text(item[1])
            if user_text or assistant_text:
                tuple_turns.append({"user": user_text, "assistant": assistant_text})
        return tuple_turns

    turns: list[dict[str, str]] = []
    pending_user = ""
    for item in history:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip().lower()
        text = _message_content_to_text(item.get("content"))
        if role == "user":
            if pending_user:
                turns.append({"user": pending_user, "assistant": ""})
            pending_user = text
            continue
        if role == "assistant":
            if pending_user:
                turns.append({"user": pending_user, "assistant": text})
                pending_user = ""
            elif text:
                turns.append({"user": "", "assistant": text})

    if pending_user:
        turns.append({"user": pending_user, "assistant": ""})
    return [turn for turn in turns if turn.get("user") or turn.get("assistant")]


def _supports_gradio_param(callable_obj: Any, param_name: str) -> bool:
    try:
        signature = inspect.signature(callable_obj)
    except Exception:
        return False
    return param_name in signature.parameters


def _resolve_default_model_input(*, default_model: Optional[str], config_path: Optional[str]) -> str:
    explicit = str(default_model or os.getenv("FINETREE_PLAYGROUND_MODEL") or "").strip()
    if explicit:
        return explicit

    candidate_config_path = str(config_path or os.getenv("FINETREE_QWEN_CONFIG") or "").strip()
    if candidate_config_path:
        try:
            from ..finetune.config import load_finetune_config

            cfg = load_finetune_config(candidate_config_path)
            configured = str(cfg.inference.model_path or cfg.model.base_model or "").strip()
            if configured:
                return configured
        except Exception:
            pass

    return "Qwen/Qwen3.5-27B"


def create_demo(*, api_base_url: Optional[str] = None, default_model: Optional[str] = None, config_path: Optional[str] = None) -> Any:
    try:
        import gradio as gr
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("Pod playground requires gradio. Install with `pip install gradio`.") from exc

    pod_api_key = _resolve_pod_api_key()
    resolved_base_url = _resolve_api_base_url(api_base_url)
    timeout_sec = float(str(os.getenv("FINETREE_PLAYGROUND_TIMEOUT_SEC") or "600"))
    resolved_default_model = _resolve_default_model_input(default_model=default_model, config_path=config_path)

    default_system_prompt = (
        "You are a precise OCR/extraction assistant. "
        "Keep replies concise and non-thinking."
    )
    example_path = _default_example_image_path()
    default_image_value = str(example_path) if example_path else None

    def _chat(
        message: str,
        history: list[Any],
        image_path: Optional[str],
        system_prompt: str,
        model_name: str,
        temperature: float,
        top_p: float,
        max_tokens: int,
    ) -> str:
        user_prompt = str(message or "").strip()
        if not user_prompt:
            return "Please enter a prompt."

        history_turns = _history_messages_to_turns(history)
        selected_model = str(model_name or "").strip() or resolved_default_model
        image_data_url = _DEFAULT_TINY_IMAGE_DATA_URL
        image_path_raw = str(image_path or "").strip()
        if image_path_raw:
            try:
                image_data_url = _image_file_to_data_url(Path(image_path_raw))
            except Exception as exc:
                return f"Image load error: {exc}"

        if _is_gemini_model_requested(selected_model):
            gemini_prompt = _build_gemini_prompt(
                system_prompt=str(system_prompt or ""),
                user_prompt=user_prompt,
                history=history_turns,
            )
            try:
                return _generate_gemini_response(
                    model_name=selected_model,
                    prompt=gemini_prompt,
                    image_path=image_path_raw or None,
                    image_data_url=image_data_url,
                )
            except Exception as exc:
                return f"Gemini error: {exc}"

        request_payload = _build_openai_chat_payload(
            {
                "system_prompt": str(system_prompt or ""),
                "user_prompt": user_prompt,
                "history": history_turns,
                "model": selected_model,
                "temperature": float(temperature),
                "top_p": float(top_p),
                "max_tokens": int(max_tokens),
                "image_data_url": image_data_url,
            }
        )
        url = f"{resolved_base_url}/v1/chat/completions"
        try:
            upstream = _post_json(url=url, body=request_payload, api_key=pod_api_key, timeout_sec=timeout_sec)
        except Exception as exc:
            return f"Upstream error: {exc}"
        return _extract_assistant_text(upstream)

    image_input = gr.Image(type="filepath", label="Image (optional)", value=default_image_value)
    system_prompt_input = gr.Textbox(label="System Prompt", lines=4, value=default_system_prompt)
    model_input = gr.Textbox(label="Model", value=resolved_default_model)
    temperature_input = gr.Slider(label="Temperature", minimum=0.0, maximum=2.0, step=0.01, value=0.7)
    top_p_input = gr.Slider(label="Top P", minimum=0.01, maximum=1.0, step=0.01, value=0.8)
    max_tokens_input = gr.Slider(label="Max Tokens", minimum=1, maximum=4096, step=1, value=120)
    chatbot_kwargs: dict[str, Any] = {"height": 620}
    supports_message_type = _supports_gradio_param(gr.Chatbot, "type")
    if supports_message_type:
        chatbot_kwargs["type"] = "messages"
    chatbot = gr.Chatbot(**chatbot_kwargs)

    chat_interface_kwargs: dict[str, Any] = {
        "fn": _chat,
        "chatbot": chatbot,
        "title": "FineTree Pod Chat Playground (5555)",
        "description": "Simple Gradio chatbot for local Qwen inference via the pod API.",
        "additional_inputs": [
            image_input,
            system_prompt_input,
            model_input,
            temperature_input,
            top_p_input,
            max_tokens_input,
        ],
    }

    if supports_message_type and _supports_gradio_param(gr.ChatInterface, "type"):
        chat_interface_kwargs["type"] = "messages"

    if _supports_gradio_param(gr.ChatInterface, "additional_inputs_accordion"):
        chat_interface_kwargs["additional_inputs_accordion"] = gr.Accordion("Inference Settings", open=True)
    elif _supports_gradio_param(gr.ChatInterface, "additional_inputs_accordion_name"):
        chat_interface_kwargs["additional_inputs_accordion_name"] = "Inference Settings"

    return gr.ChatInterface(**chat_interface_kwargs)


def _playground_html(*, default_model: str, default_image_data_url: Optional[str]) -> str:
    default_image_js = json.dumps(default_image_data_url or _DEFAULT_TINY_IMAGE_DATA_URL)
    return f"""<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>FineTree Pod Playground</title>
  <style>
    :root {{ --bg:#f6f4ef; --panel:#fffefb; --ink:#1f2430; --accent:#0b6e4f; --line:#d8d3c4; }}
    * {{ box-sizing: border-box; }}
    body {{ margin:0; font-family: ui-sans-serif, system-ui, -apple-system, sans-serif; background:linear-gradient(145deg,#f6f4ef,#ece7d8); color:var(--ink); }}
    .wrap {{ max-width: 1200px; margin: 24px auto; padding: 0 16px; }}
    .card {{ background: var(--panel); border:1px solid var(--line); border-radius: 16px; padding: 16px; box-shadow: 0 8px 28px rgba(21,29,41,0.08); }}
    .grid {{ display:grid; grid-template-columns: 360px 1fr; gap:16px; }}
    label {{ font-weight: 600; font-size: 13px; display:block; margin-bottom: 6px; }}
    input, textarea, button {{ width:100%; border:1px solid var(--line); border-radius: 10px; padding:10px; font: inherit; background:white; }}
    textarea {{ min-height: 90px; resize: vertical; }}
    .row {{ display:grid; grid-template-columns: repeat(3, 1fr); gap:10px; }}
    .status {{ font-size: 12px; min-height: 20px; margin-top: 8px; color:#6b7280; }}
    .run {{ background: var(--accent); color:white; border-color: var(--accent); font-weight:700; cursor:pointer; }}
    .run:disabled {{ opacity:0.7; cursor:not-allowed; }}
    .secondary {{ background:#f5f5f4; color:#1f2937; border-color:#d4d4d4; font-weight:600; cursor:pointer; }}
    .chat {{ border:1px solid var(--line); border-radius: 12px; background:white; min-height: 520px; display:grid; grid-template-rows: 1fr auto; overflow:hidden; }}
    .log {{ padding:14px; overflow:auto; display:flex; flex-direction:column; gap:10px; background:linear-gradient(180deg,#fffefb,#f7f7f5); }}
    .bubble {{ max-width: 86%; border:1px solid var(--line); border-radius:12px; padding:8px 10px; white-space:pre-wrap; }}
    .bubble.user {{ align-self:flex-end; background:#e8f4ef; border-color:#cce8dd; }}
    .bubble.assistant {{ align-self:flex-start; background:#fff; }}
    .who {{ font-size:11px; font-weight:700; opacity:0.7; margin-bottom:4px; text-transform:uppercase; letter-spacing:0.03em; }}
    .composer {{ border-top:1px solid var(--line); padding:12px; background:#fffefc; }}
    .composer textarea {{ min-height: 88px; }}
    .actions {{ display:grid; grid-template-columns: 1fr 1fr; gap:10px; margin-top:8px; }}
    .muted {{ font-size:12px; color:#6b7280; margin-top:8px; }}
    @media (max-width: 900px) {{ .grid, .row {{ grid-template-columns: 1fr; }} }}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h2>FineTree Pod Chat Playground (5555)</h2>
      <div class="grid">
        <div>
          <label>System Prompt</label>
          <textarea id="systemPrompt">You are a precise OCR/extraction assistant. Keep replies concise and non-thinking.</textarea>
          <label>Image (optional)</label>
          <input id="imageInput" type="file" accept="image/*" />
          <div class="row" style="margin-top:10px;">
            <div>
              <label>Model</label>
              <input id="model" value="{html.escape(default_model)}" />
            </div>
            <div>
              <label>Temperature</label>
              <input id="temperature" type="number" step="0.01" min="0" max="2" value="0.7" />
            </div>
            <div>
              <label>Top P</label>
              <input id="topP" type="number" step="0.01" min="0" max="1" value="0.8" />
            </div>
          </div>
          <div style="margin-top:10px;">
            <label>Max Tokens</label>
            <input id="maxTokens" type="number" min="1" max="4096" value="120" />
          </div>
          <p class="muted">Chat history is included as conversation context for each turn. Streaming is enabled.</p>
          <div id="status" class="status"></div>
        </div>
        <div class="chat">
          <div id="chatLog" class="log"></div>
          <div class="composer">
            <label>Prompt</label>
            <textarea id="userPrompt" placeholder="Ask a question about the uploaded image or continue the chat..."></textarea>
            <div class="actions">
              <button class="run" id="sendBtn">Send (Streaming)</button>
              <button class="secondary" id="resetBtn">Reset Chat</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
    let imageDataUrl = {default_image_js};
    const turns = [];
    const statusEl = document.getElementById("status");
    const chatLogEl = document.getElementById("chatLog");
    const userPromptEl = document.getElementById("userPrompt");
    const sendBtn = document.getElementById("sendBtn");
    const resetBtn = document.getElementById("resetBtn");

    function appendBubble(role, text) {{
      const bubble = document.createElement("div");
      bubble.className = `bubble ${{role}}`;
      const who = document.createElement("div");
      who.className = "who";
      who.textContent = role === "user" ? "You" : "Assistant";
      const body = document.createElement("div");
      body.textContent = text;
      bubble.appendChild(who);
      bubble.appendChild(body);
      chatLogEl.appendChild(bubble);
      chatLogEl.scrollTop = chatLogEl.scrollHeight;
      return body;
    }}

    appendBubble("assistant", "Chat ready. Upload an image if needed, then send a prompt.");

    document.getElementById("imageInput").addEventListener("change", async (e) => {{
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {{ imageDataUrl = String(reader.result || ""); statusEl.textContent = "Image loaded."; }};
      reader.readAsDataURL(file);
    }});

    resetBtn.addEventListener("click", () => {{
      turns.length = 0;
      chatLogEl.innerHTML = "";
      appendBubble("assistant", "Chat reset.");
      statusEl.textContent = "Conversation cleared.";
    }});

    async function streamTurn() {{
      const userPrompt = String(userPromptEl.value || "").trim();
      if (!userPrompt) {{
        statusEl.textContent = "Enter a prompt first.";
        return;
      }}

      sendBtn.disabled = true;
      statusEl.textContent = "Streaming...";
      appendBubble("user", userPrompt);
      const assistantBody = appendBubble("assistant", "");
      let assistantText = "";

      const payload = {{
        system_prompt: document.getElementById("systemPrompt").value,
        user_prompt: userPrompt,
        history: turns,
        model: document.getElementById("model").value,
        temperature: Number(document.getElementById("temperature").value || 0.7),
        top_p: Number(document.getElementById("topP").value || 0.8),
        max_tokens: Number(document.getElementById("maxTokens").value || 120),
        image_data_url: imageDataUrl
      }};
      try {{
        const resp = await fetch("/api/chat/stream", {{
          method: "POST",
          headers: {{ "Content-Type": "application/json" }},
          body: JSON.stringify(payload)
        }});
        if (!resp.ok) {{
          const message = await resp.text();
          throw new Error(message || `HTTP ${{resp.status}}`);
        }}
        if (!resp.body) {{
          throw new Error("Response body is unavailable for streaming.");
        }}

        const reader = resp.body.getReader();
        const decoder = new TextDecoder();
        let doneSeen = false;
        let buffer = "";

        const parseEvent = (eventText) => {{
          const lines = eventText.split(/\\r?\\n/);
          const dataLines = [];
          for (const line of lines) {{
            if (line.startsWith("data:")) {{
              dataLines.push(line.slice(5).trimStart());
            }}
          }}
          if (dataLines.length === 0) return;
          const data = dataLines.join("\\n");
          if (data === "[DONE]") {{
            doneSeen = true;
            return;
          }}
          let payload;
          try {{
            payload = JSON.parse(data);
          }} catch (_err) {{
            return;
          }}
          if (payload.error) {{
            const message = payload.error.message || payload.error || "Unknown streaming error";
            throw new Error(String(message));
          }}
          const choice = (payload.choices && payload.choices[0]) || null;
          const token = choice && choice.delta && typeof choice.delta.content === "string"
            ? choice.delta.content
            : null;
          if (token) {{
            assistantText += token;
            assistantBody.textContent = assistantText;
            chatLogEl.scrollTop = chatLogEl.scrollHeight;
          }}
        }};

        while (true) {{
          const {{ value, done }} = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, {{ stream: true }});
          let match = buffer.match(/\\r?\\n\\r?\\n/);
          while (match) {{
            const boundary = match.index ?? -1;
            if (boundary < 0) break;
            const eventText = buffer.slice(0, boundary);
            buffer = buffer.slice(boundary + match[0].length);
            parseEvent(eventText);
            match = buffer.match(/\\r?\\n\\r?\\n/);
          }}
        }}
        buffer += decoder.decode();
        if (buffer.trim()) {{
          parseEvent(buffer.trim());
        }}
        statusEl.textContent = doneSeen ? "Done." : "Stream closed.";
        turns.push({{ user: userPrompt, assistant: assistantText }});
        userPromptEl.value = "";
      }} catch (err) {{
        statusEl.textContent = "Error.";
        const errText = String(err);
        assistantBody.textContent = errText;
      }} finally {{
        sendBtn.disabled = false;
      }}
    }}

    sendBtn.addEventListener("click", streamTurn);
    userPromptEl.addEventListener("keydown", (event) => {{
      if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {{
        event.preventDefault();
        streamTurn();
      }}
    }});
  </script>
</body>
</html>"""


def create_app(*, api_base_url: Optional[str] = None, default_model: Optional[str] = None) -> Any:
    try:
        import secrets as py_secrets
        from fastapi import Depends, FastAPI, HTTPException
        from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
        from fastapi.security import HTTPBasic, HTTPBasicCredentials
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("Pod playground requires fastapi, pydantic and uvicorn.") from exc

    username, password = _resolve_basic_auth_credentials()
    pod_api_key = _resolve_pod_api_key()
    resolved_base_url = _resolve_api_base_url(api_base_url)
    timeout_sec = float(str(os.getenv("FINETREE_PLAYGROUND_TIMEOUT_SEC") or "600"))
    served_model = str(default_model or os.getenv("FINETREE_SERVED_MODEL_NAME") or "qwen-gt").strip()

    example_path = _default_example_image_path()
    default_image_data_url = _image_file_to_data_url(example_path) if example_path else None

    security = HTTPBasic(auto_error=False)
    app = FastAPI(title="FineTree Pod Playground", docs_url=None, redoc_url=None, openapi_url=None)

    def _require_auth(credentials: Optional[HTTPBasicCredentials] = Depends(security)) -> None:
        if credentials is None:
            raise HTTPException(
                status_code=401,
                detail="Unauthorized",
                headers={"WWW-Authenticate": "Basic"},
            )
        valid_user = py_secrets.compare_digest(credentials.username, username)
        valid_pass = py_secrets.compare_digest(credentials.password, password)
        if not (valid_user and valid_pass):
            raise HTTPException(
                status_code=401,
                detail="Unauthorized",
                headers={"WWW-Authenticate": "Basic"},
            )

    @app.get("/", response_class=HTMLResponse)
    async def index(_auth: None = Depends(_require_auth)) -> str:
        return _playground_html(default_model=served_model, default_image_data_url=default_image_data_url)

    @app.post("/api/chat")
    async def chat(payload: PlaygroundChatRequest, _auth: None = Depends(_require_auth)) -> Any:
        selected_model = str(payload.model or "").strip() or served_model
        if _is_gemini_model_requested(selected_model):
            gemini_prompt = _build_gemini_prompt(
                system_prompt=str(payload.system_prompt or ""),
                user_prompt=str(payload.user_prompt or ""),
                history=_normalize_history(payload.history),
            )
            try:
                assistant_text = _generate_gemini_response(
                    model_name=selected_model,
                    prompt=gemini_prompt,
                    image_path=None,
                    image_data_url=payload.image_data_url,
                )
            except Exception as exc:
                return JSONResponse({"ok": False, "error": str(exc)}, status_code=502)
            return JSONResponse(
                {
                    "ok": True,
                    "assistant_text": assistant_text,
                    "response": {
                        "provider": "gemini",
                        "model": _resolve_gemini_model_name(selected_model),
                    },
                }
            )

        request_payload = _build_openai_chat_payload(payload.model_dump())
        url = f"{resolved_base_url}/v1/chat/completions"
        try:
            upstream = _post_json(url=url, body=request_payload, api_key=pod_api_key, timeout_sec=timeout_sec)
        except Exception as exc:
            return JSONResponse({"ok": False, "error": str(exc)}, status_code=502)
        return JSONResponse(
            {
                "ok": True,
                "assistant_text": _extract_assistant_text(upstream),
                "response": upstream,
            }
        )

    @app.post("/api/chat/stream")
    async def chat_stream(payload: PlaygroundChatRequest, _auth: None = Depends(_require_auth)) -> Any:
        selected_model = str(payload.model or "").strip() or served_model
        if _is_gemini_model_requested(selected_model):
            gemini_prompt = _build_gemini_prompt(
                system_prompt=str(payload.system_prompt or ""),
                user_prompt=str(payload.user_prompt or ""),
                history=_normalize_history(payload.history),
            )
            resolved_gemini_model = _resolve_gemini_model_name(selected_model)

            def _gemini_stream() -> Iterator[bytes]:
                done_sent = False
                try:
                    for token in _stream_gemini_response(
                        model_name=selected_model,
                        prompt=gemini_prompt,
                        image_path=None,
                        image_data_url=payload.image_data_url,
                    ):
                        if not token:
                            continue
                        chunk = {"choices": [{"delta": {"content": token}}], "model": resolved_gemini_model}
                        yield f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n".encode("utf-8")
                    done_sent = True
                    yield b"data: [DONE]\n\n"
                except Exception as exc:
                    err = {"error": {"message": str(exc), "type": "server_error"}}
                    yield f"data: {json.dumps(err, ensure_ascii=False)}\n\n".encode("utf-8")
                finally:
                    if not done_sent:
                        yield b"data: [DONE]\n\n"

            return StreamingResponse(_gemini_stream(), media_type="text/event-stream")

        request_payload = _build_openai_chat_payload(payload.model_dump())
        request_payload["stream"] = True
        url = f"{resolved_base_url}/v1/chat/completions"

        def _proxy_stream() -> Iterator[bytes]:
            done_sent = False
            try:
                for event_data in _iter_sse_data_events(
                    url=url,
                    body=request_payload,
                    api_key=pod_api_key,
                    timeout_sec=timeout_sec,
                ):
                    if not event_data:
                        continue
                    if event_data == "[DONE]":
                        done_sent = True
                        yield b"data: [DONE]\n\n"
                        break
                    yield f"data: {event_data}\n\n".encode("utf-8")
            except Exception as exc:
                err = {"error": {"message": str(exc), "type": "server_error"}}
                yield f"data: {json.dumps(err, ensure_ascii=False)}\n\n".encode("utf-8")
            finally:
                if not done_sent:
                    yield b"data: [DONE]\n\n"

        return StreamingResponse(_proxy_stream(), media_type="text/event-stream")

    return app


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="FineTree Pod Playground app.")
    parser.add_argument("--config", default=None, help="FineTree YAML config path (kept for compatibility).")
    parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0).")
    parser.add_argument("--port", type=int, default=5555, help="Bind port (default: 5555).")
    parser.add_argument("--api-base-url", default=None, help="Internal pod API base URL (default: http://127.0.0.1:6666).")
    parser.add_argument("--model", default=None, help="Default model value shown in the chat playground.")
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    username, password = _resolve_basic_auth_credentials()
    demo = create_demo(
        api_base_url=args.api_base_url,
        default_model=args.model,
        config_path=args.config,
    )
    demo.queue(default_concurrency_limit=1).launch(
        server_name=str(args.host),
        server_port=int(args.port),
        auth=(username, password),
        share=False,
        show_error=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
